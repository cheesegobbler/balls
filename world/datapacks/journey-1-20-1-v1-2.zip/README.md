# **Journey**
## Welcome to Journey !
### A simple yet wonderful way of displaying an area's name throughout your voyages.
### *Initially released as Hope's* **Dark Souls Titles**


![Screenshot](https://i.imgur.com/4XQVYgF.png)
